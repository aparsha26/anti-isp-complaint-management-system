# NetWave ISP Management System — Setup Guide

## Prerequisites
- WAMP Server installed and running
- PHP 7.4+, MySQL 5.7+
- A modern browser (Chrome, Edge, Firefox)

---

## Step 1 — Copy Files

Place the entire `anti/` folder inside your WAMP `www` directory:

```
C:\wamp64\www\anti\
```

---

## Step 2 — Import Database

1. Open **phpMyAdmin**: http://localhost/phpmyadmin
2. Click **"New"** → Create database named **`isp_db`**
3. Click the `isp_db` database → Go to **Import** tab
4. Click **Choose File** → select `C:\wamp64\www\anti\setup.sql`
5. Click **Go** — The database and seed data will be imported

---

## Step 3 — Verify Database Config

Open `C:\wamp64\www\anti\api\config.php` and confirm:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'isp_db');
define('DB_USER', 'root');
define('DB_PASS', '');   // No password
```

---

## Step 4 — Launch the App

Open your browser and go to:

```
http://localhost/anti/index.html
```

---

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| **Admin** | admin@isp.com | admin123 |
| **Service Provider** | provider@isp.com | provider123 |
| **Customer** | rahul@gmail.com | cust123 |

---

## Portal URLs

| Portal | URL |
|--------|-----|
| 🏠 Landing Page | http://localhost/anti/index.html |
| 🛡️ Admin Login | http://localhost/anti/admin/login.html |
| 🔧 Provider Login | http://localhost/anti/provider/login.html |
| 👤 Customer Login | http://localhost/anti/customer/login.html |
| 📝 Customer Signup | http://localhost/anti/customer/signup.html |

---

## File Structure

```
anti/
├── index.html                    ← Animated landing page
├── setup.sql                     ← Full database schema + seed data
├── css/
│   └── style.css                 ← Global design system
├── js/
│   └── main.js                   ← Global JS utilities
├── api/
│   ├── config.php                ← DB connection + helpers
│   ├── auth/
│   │   ├── login.php
│   │   ├── signup.php
│   │   ├── logout.php
│   │   └── check_session.php
│   ├── admin/
│   │   ├── customers.php         ← Customer CRUD
│   │   ├── plans.php             ← Plan management
│   │   ├── offers.php            ← Festival offers
│   │   ├── complaints.php        ← Complaint oversight
│   │   └── reports.php           ← Analytics & charts
│   ├── provider/
│   │   ├── complaints.php        ← Complaint queue + actions
│   │   └── services.php          ← Zone management
│   └── customer/
│       ├── plans.php             ← Browse plans
│       ├── payment.php           ← Billing + payment history
│       ├── complaint.php         ← Submit & track complaints
│       ├── feedback.php          ← Star rating + reviews
│       ├── referral.php          ← Referral tracking
│       └── profile.php           ← Account profile
├── admin/
│   ├── login.html
│   ├── dashboard.html            ← Charts, stats, quick actions
│   ├── customers.html            ← Full CRUD with search/filter
│   ├── plans.html                ← Plan cards with CRUD
│   ├── offers.html               ← Festival offer management
│   ├── complaints.html           ← Complaint oversight
│   └── reports.html              ← Analytics with 4 charts
├── provider/
│   ├── login.html
│   ├── dashboard.html
│   ├── complaints.html           ← Action queue with timeline
│   └── services.html             ← Zone status monitor
└── customer/
    ├── login.html
    ├── signup.html               ← 3-step registration
    ├── dashboard.html            ← Plan widget, quick links
    ├── plans.html                ← Browse with offers
    ├── payment.html              ← 4 payment methods
    ├── complaint.html            ← Submit + timeline tracker
    ├── feedback.html             ← Star rating + community reviews
    └── referral.html             ← Share code, earn rewards
```

---

## Features Summary

### Admin Portal
- Dashboard with live Chart.js charts (revenue, customers, plans, complaints)
- Customer management with search, filter, CRUD, and pagination
- Plan creation & editing with feature lists
- Festival offers with promo codes and date ranges
- Complaint oversight with priority/status management
- Reports & analytics with 4 data visualizations

### Service Provider Portal
- Dashboard with open/resolved complaint stats
- Complaint queue with action logging (visited/called/fixed/escalated)
- Service zone monitoring with status updates (Operational/Maintenance/Outage)

### Customer Portal
- Animated landing page with interactive globe and particle network
- 3-step signup with referral code support and password strength meter
- Dashboard with data usage bar, active plan info, and quick links
- Plan browser with festival offers applied, promo code entry
- Payment with 4 methods: UPI, Card, Net Banking, Wallet
- Complaint box with real-time status tracker and response timeline
- Feedback with animated star rating and community reviews
- Referral program with WhatsApp/Telegram share and reward tracking

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| White page on login | Ensure WAMP is running and file is under `www/anti/` |
| "Connection failed" | Check `api/config.php` DB credentials |
| Session not persisting | Ensure cookies are enabled in browser |
| API 404 error | Confirm `.htaccess` / Apache rewrite is not needed (we use query params) |
| "No plans found" | Re-run `setup.sql` in phpMyAdmin — seed data includes plans |
