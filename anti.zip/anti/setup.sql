-- =============================================
-- ISP MANAGEMENT SYSTEM - DATABASE SETUP
-- Run this in phpMyAdmin or MySQL command line
-- =============================================

CREATE DATABASE IF NOT EXISTS isp_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE isp_db;

-- =============================================
-- USERS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'provider', 'customer') NOT NULL DEFAULT 'customer',
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    referral_code VARCHAR(20) UNIQUE,
    referred_by VARCHAR(20),
    avatar VARCHAR(255),
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- PLANS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    speed VARCHAR(50) NOT NULL,
    upload_speed VARCHAR(50),
    data_limit VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    validity_days INT DEFAULT 30,
    description TEXT,
    features TEXT,
    badge VARCHAR(50),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- SUBSCRIPTIONS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    amount_paid DECIMAL(10,2),
    status ENUM('active', 'expired', 'cancelled', 'pending') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
);

-- =============================================
-- PAYMENTS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_id INT,
    subscription_id INT,
    amount DECIMAL(10,2) NOT NULL,
    method ENUM('card', 'upi', 'netbanking', 'wallet') NOT NULL,
    transaction_id VARCHAR(100) UNIQUE,
    gateway_ref VARCHAR(200),
    notes TEXT,
    status ENUM('pending', 'success', 'failed', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE SET NULL
);

-- =============================================
-- COMPLAINTS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(20) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    category ENUM('connectivity','speed','billing','installation','hardware','other') DEFAULT 'other',
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    attachment VARCHAR(255),
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
    assigned_to INT,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- COMPLAINT ACTIONS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS complaint_actions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id INT NOT NULL,
    provider_id INT NOT NULL,
    action_type ENUM('visited','fixed','escalated','note','called') DEFAULT 'note',
    notes TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
    FOREIGN KEY (provider_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
-- FEEDBACK TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    category ENUM('speed','support','billing','overall','installation') DEFAULT 'overall',
    comment TEXT,
    is_public TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
-- OFFERS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    event_name VARCHAR(100),
    discount_percent DECIMAL(5,2),
    discount_amount DECIMAL(10,2),
    plan_id INT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    promo_code VARCHAR(50) UNIQUE,
    max_uses INT DEFAULT 0,
    used_count INT DEFAULT 0,
    status ENUM('active','inactive','expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE SET NULL
);

-- =============================================
-- REFERRALS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_id INT NOT NULL,
    reward_amount DECIMAL(10,2) DEFAULT 100.00,
    status ENUM('pending','credited','expired') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (referred_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
-- SERVICE ZONES TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS service_zones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    zone_name VARCHAR(100) NOT NULL,
    area VARCHAR(200),
    provider_id INT,
    status ENUM('operational','maintenance','outage') DEFAULT 'operational',
    last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (provider_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- SEED DATA
-- =============================================

-- Admin (password: admin123)
INSERT INTO users (name, email, phone, password, role, status) VALUES
('Super Admin', 'admin@isp.com', '9876543210', SHA2('admin123', 256), 'admin', 'active');

-- Service Provider (password: provider123)
INSERT INTO users (name, email, phone, password, role, status) VALUES
('TechCare Support', 'provider@isp.com', '9876543211', SHA2('provider123', 256), 'provider', 'active'),
('Field Technician', 'tech@isp.com', '9876543215', SHA2('provider123', 256), 'provider', 'active');

-- Customers (password: cust123)
INSERT INTO users (name, email, phone, password, role, address, city, state, pincode, referral_code, status) VALUES
('Rahul Sharma', 'rahul@gmail.com', '9876543212', SHA2('cust123', 256), 'customer', '123 MG Road', 'Bangalore', 'Karnataka', '560001', 'REF001', 'active'),
('Priya Patel', 'priya@gmail.com', '9876543213', SHA2('cust123', 256), 'customer', '456 FC Road', 'Pune', 'Maharashtra', '411001', 'REF002', 'active'),
('Amit Kumar', 'amit@gmail.com', '9876543214', SHA2('cust123', 256), 'customer', '789 Park Street', 'Delhi', 'Delhi', '110001', 'REF003', 'active'),
('Sneha Reddy', 'sneha@gmail.com', '9876543216', SHA2('cust123', 256), 'customer', '321 Jubilee Hills', 'Hyderabad', 'Telangana', '500033', 'REF004', 'active'),
('Vijay Nair', 'vijay@gmail.com', '9876543217', SHA2('cust123', 256), 'customer', '654 Marine Drive', 'Mumbai', 'Maharashtra', '400001', 'REF005', 'active');

-- Internet Plans
INSERT INTO plans (name, speed, upload_speed, data_limit, price, validity_days, description, features, badge) VALUES
('Basic', '10 Mbps', '5 Mbps', '100 GB', 399.00, 30, 'Perfect for light browsing and social media', 'Social Media,Email,Light Streaming,24/7 Support', NULL),
('Standard', '50 Mbps', '25 Mbps', '300 GB', 699.00, 30, 'Great for HD streaming and gaming', 'HD Streaming,Online Gaming,Video Calls,Priority Support', 'Popular'),
('Pro', '100 Mbps', '50 Mbps', 'Unlimited', 999.00, 30, 'High-speed unlimited for power users', 'Unlimited Data,4K Streaming,Fast Gaming,Dedicated Support', 'Best Value'),
('Ultra Fiber', '200 Mbps', '100 Mbps', 'Unlimited', 1499.00, 30, 'Ultra-fast fiber for enterprises & heavy users', 'Ultra Speed,Unlimited Data,Static IP,SLA 99.9%', 'Enterprise'),
('Student Pack', '25 Mbps', '10 Mbps', '150 GB', 499.00, 30, 'Special plan designed for students', 'Study Tools,E-learning,Video Calls,Budget Friendly', 'Student');

-- Subscriptions
INSERT INTO subscriptions (user_id, plan_id, start_date, end_date, amount_paid, status) VALUES
(4, 2, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 699.00, 'active'),
(5, 3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 999.00, 'active'),
(6, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 399.00, 'active'),
(7, 4, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 1499.00, 'active'),
(8, 5, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 499.00, 'active');

-- Payments
INSERT INTO payments (user_id, plan_id, amount, method, transaction_id, status) VALUES
(4, 2, 699.00, 'upi', 'TXN001234567', 'success'),
(5, 3, 999.00, 'card', 'TXN001234568', 'success'),
(6, 1, 399.00, 'wallet', 'TXN001234569', 'success'),
(7, 4, 1499.00, 'netbanking', 'TXN001234570', 'success'),
(8, 5, 499.00, 'upi', 'TXN001234571', 'success');

-- Complaints
INSERT INTO complaints (ticket_id, user_id, category, subject, description, priority, status, assigned_to) VALUES
('TKT-2024-001', 4, 'connectivity', 'No internet connection since morning', 'Unable to connect since 8 AM. Modem lights showing red. Tried restarting multiple times.', 'high', 'in_progress', 2),
('TKT-2024-002', 5, 'speed', 'Very slow internet speed', 'Getting only 5 Mbps on a 100 Mbps plan. Running speed tests confirms slow speed.', 'medium', 'open', NULL),
('TKT-2024-003', 6, 'billing', 'Double charged this month', 'I was charged twice for the same plan in April. Please refund the extra amount.', 'urgent', 'open', NULL),
('TKT-2024-004', 7, 'installation', 'New connection setup incomplete', 'Technician visited but did not install the router properly. Connection drops every hour.', 'high', 'resolved', 2),
('TKT-2024-005', 8, 'hardware', 'Modem malfunction', 'The provided modem frequently disconnects. Need replacement.', 'medium', 'open', NULL);

-- Complaint Actions
INSERT INTO complaint_actions (complaint_id, provider_id, action_type, notes) VALUES
(1, 2, 'visited', 'Visited customer premises. Found modem issue. Replaced modem.'),
(1, 2, 'fixed', 'Connection restored. Customer confirmed working.'),
(4, 2, 'visited', 'Visited and properly configured router. Setup cables correctly.'),
(4, 2, 'fixed', 'All connections verified and stable. Issue resolved.');

-- Festival Offers
INSERT INTO offers (title, description, event_name, discount_percent, plan_id, start_date, end_date, promo_code, max_uses, status) VALUES
('Diwali Special Offer', 'Get 30% off on Pro plan this Diwali! Limited time offer.', 'Diwali', 30.00, 3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 15 DAY), 'DIWALI30', 500, 'active'),
('New Year Bonanza', 'Start the new year with 20% off on any plan!', 'New Year', 20.00, NULL, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'NEWYEAR20', 1000, 'active'),
('Student Season Sale', 'Back to school! 15% off on Student Pack.', 'Back to School', 15.00, 5, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 45 DAY), 'STUDENT15', 300, 'active');

-- Feedback
INSERT INTO feedback (user_id, rating, category, comment) VALUES
(4, 5, 'speed', 'Excellent internet speed! Very happy with the service.'),
(5, 4, 'support', 'Support team was helpful and resolved my issue quickly.'),
(6, 3, 'overall', 'Service is okay but sometimes slow during peak hours.'),
(7, 5, 'overall', 'Best ISP in the city! Highly recommended.'),
(8, 4, 'installation', 'Installation was smooth and professional.');

-- Referrals
INSERT INTO referrals (referrer_id, referred_id, reward_amount, status) VALUES
(4, 5, 100.00, 'credited'),
(4, 6, 100.00, 'credited');

-- Service Zones
INSERT INTO service_zones (zone_name, area, provider_id, status) VALUES
('Zone A - South Bangalore', 'Koramangala, BTM Layout, HSR Layout', 2, 'operational'),
('Zone B - North Bangalore', 'Hebbal, Yelahanka, Sahakarnagar', 2, 'operational'),
('Zone C - East Bangalore', 'Whitefield, Marathahalli, KR Puram', 3, 'maintenance'),
('Zone D - West Bangalore', 'Rajajinagar, Vijaynagar, Yeshwanthpur', 3, 'operational');

SELECT 'Database setup complete!' AS message;
