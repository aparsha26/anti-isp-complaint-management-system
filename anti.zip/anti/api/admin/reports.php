<?php
require_once '../config.php';
requireAuth('admin');

// Dashboard overview stats
$stats = [];

// Total customers
$stats['total_customers'] = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
$stats['active_customers'] = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer' AND status='active'")->fetchColumn();

// Revenue
$stats['total_revenue'] = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='success'")->fetchColumn();
$stats['monthly_revenue'] = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='success' AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetchColumn();

// Complaints
$stats['open_complaints'] = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status='open'")->fetchColumn();
$stats['resolved_complaints'] = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status='resolved'")->fetchColumn();
$stats['total_complaints'] = $pdo->query("SELECT COUNT(*) FROM complaints")->fetchColumn();

// Active subscriptions
$stats['active_subscriptions'] = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status='active'")->fetchColumn();

// Plans distribution
$planDist = $pdo->query("
    SELECT p.name, COUNT(s.id) as count 
    FROM plans p 
    LEFT JOIN subscriptions s ON s.plan_id=p.id AND s.status='active' 
    GROUP BY p.id, p.name 
    ORDER BY count DESC
")->fetchAll();

// Monthly revenue chart (last 6 months)
$monthlyRevenue = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') as month, 
           MONTH(created_at) as m, YEAR(created_at) as y,
           SUM(amount) as revenue
    FROM payments 
    WHERE status='success' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY YEAR(created_at), MONTH(created_at)
    ORDER BY y ASC, m ASC
")->fetchAll();

// Top plans by revenue
$topPlans = $pdo->query("
    SELECT p.name, COUNT(pay.id) as transactions, SUM(pay.amount) as revenue
    FROM payments pay
    LEFT JOIN plans p ON pay.plan_id = p.id
    WHERE pay.status='success'
    GROUP BY p.id, p.name
    ORDER BY revenue DESC
    LIMIT 5
")->fetchAll();

// Recent payments
$recentPayments = $pdo->query("
    SELECT pay.*, u.name as customer_name, p.name as plan_name
    FROM payments pay
    JOIN users u ON pay.user_id = u.id
    LEFT JOIN plans p ON pay.plan_id = p.id
    WHERE pay.status='success'
    ORDER BY pay.created_at DESC
    LIMIT 10
")->fetchAll();

// Complaint categories
$complaintCats = $pdo->query("
    SELECT category, COUNT(*) as count FROM complaints GROUP BY category
")->fetchAll();

// New customers per month (last 6 months)
$newCustomers = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') as month,
           MONTH(created_at) as m, YEAR(created_at) as y,
           COUNT(*) as count
    FROM users WHERE role='customer' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY YEAR(created_at), MONTH(created_at)
    ORDER BY y ASC, m ASC
")->fetchAll();

// Feedback avg rating
$avgRating = $pdo->query("SELECT AVG(rating) FROM feedback")->fetchColumn();
$stats['avg_rating'] = round($avgRating, 1);

// Active offers
$stats['active_offers'] = $pdo->query("SELECT COUNT(*) FROM offers WHERE status='active'")->fetchColumn();

sendSuccess('Reports retrieved', [
    'stats'           => $stats,
    'plan_dist'       => $planDist,
    'monthly_revenue' => $monthlyRevenue,
    'top_plans'       => $topPlans,
    'recent_payments' => $recentPayments,
    'complaint_cats'  => $complaintCats,
    'new_customers'   => $newCustomers,
]);
