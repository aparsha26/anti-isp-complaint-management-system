<?php
require_once '../config.php';
requireAuth('admin');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT * FROM plans ORDER BY price ASC");
        $plans = $stmt->fetchAll();
        sendSuccess('Plans retrieved', ['plans' => $plans]);
        break;

    case 'POST':
        $input = getInput();
        $name = sanitize($input['name'] ?? '');
        $speed = sanitize($input['speed'] ?? '');
        $upload = sanitize($input['upload_speed'] ?? '');
        $data = sanitize($input['data_limit'] ?? 'Unlimited');
        $price = (float)($input['price'] ?? 0);
        $validity = (int)($input['validity_days'] ?? 30);
        $desc = sanitize($input['description'] ?? '');
        $features = sanitize($input['features'] ?? '');
        $badge = sanitize($input['badge'] ?? '');

        if (empty($name) || empty($speed) || $price <= 0) sendError('Name, speed and price are required.');

        $stmt = $pdo->prepare("INSERT INTO plans (name,speed,upload_speed,data_limit,price,validity_days,description,features,badge,status) VALUES (?,?,?,?,?,?,?,?,?,'active')");
        $stmt->execute([$name,$speed,$upload,$data,$price,$validity,$desc,$features,$badge]);
        sendSuccess('Plan created successfully', ['id' => $pdo->lastInsertId()], 201);
        break;

    case 'PUT':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Plan ID required.');
        $input = getInput();

        $fields = [];
        $params = [];
        $allowed = ['name','speed','upload_speed','data_limit','price','validity_days','description','features','badge','status'];
        foreach ($allowed as $f) {
            if (isset($input[$f])) {
                $fields[] = "$f = ?";
                $params[] = is_string($input[$f]) ? sanitize($input[$f]) : $input[$f];
            }
        }
        if (empty($fields)) sendError('No fields to update.');
        $params[] = $id;
        $stmt = $pdo->prepare("UPDATE plans SET " . implode(',', $fields) . " WHERE id = ?");
        $stmt->execute($params);
        sendSuccess('Plan updated successfully');
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Plan ID required.');
        // Check if plan has active subscriptions
        $check = $pdo->prepare("SELECT COUNT(*) FROM subscriptions WHERE plan_id = ? AND status = 'active'");
        $check->execute([$id]);
        if ($check->fetchColumn() > 0) sendError('Cannot delete plan with active subscriptions. Deactivate it instead.');
        $stmt = $pdo->prepare("DELETE FROM plans WHERE id = ?");
        $stmt->execute([$id]);
        sendSuccess('Plan deleted successfully');
        break;

    default:
        sendError('Method not allowed', 405);
}
