<?php
require_once '../config.php';
requireAuth('admin');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $status = sanitize($_GET['status'] ?? '');
        $where = '';
        $params = [];
        if ($status) { $where = 'WHERE status = ?'; $params[] = $status; }

        // Auto-expire old offers
        $pdo->exec("UPDATE offers SET status='expired' WHERE end_date < CURDATE() AND status='active'");

        $stmt = $pdo->prepare("
            SELECT o.*, p.name as plan_name 
            FROM offers o 
            LEFT JOIN plans p ON o.plan_id = p.id
            $where
            ORDER BY o.created_at DESC
        ");
        $stmt->execute($params);
        sendSuccess('Offers retrieved', ['offers' => $stmt->fetchAll()]);
        break;

    case 'POST':
        $input = getInput();
        $title = sanitize($input['title'] ?? '');
        $desc = sanitize($input['description'] ?? '');
        $event = sanitize($input['event_name'] ?? '');
        $discPct = !empty($input['discount_percent']) ? (float)$input['discount_percent'] : null;
        $discAmt = !empty($input['discount_amount']) ? (float)$input['discount_amount'] : null;
        $planId = !empty($input['plan_id']) ? (int)$input['plan_id'] : null;
        $startDate = sanitize($input['start_date'] ?? '');
        $endDate = sanitize($input['end_date'] ?? '');
        $promoCode = strtoupper(sanitize($input['promo_code'] ?? ''));
        $maxUses = (int)($input['max_uses'] ?? 0);

        if (empty($title) || empty($startDate) || empty($endDate)) sendError('Title, start date and end date are required.');
        if (strtotime($endDate) < strtotime($startDate)) sendError('End date must be after start date.');

        $stmt = $pdo->prepare("INSERT INTO offers (title,description,event_name,discount_percent,discount_amount,plan_id,start_date,end_date,promo_code,max_uses,status) VALUES (?,?,?,?,?,?,?,?,?,?,'active')");
        $stmt->execute([$title,$desc,$event,$discPct,$discAmt,$planId,$startDate,$endDate,$promoCode,$maxUses]);
        sendSuccess('Offer created successfully', ['id' => $pdo->lastInsertId()], 201);
        break;

    case 'PUT':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Offer ID required.');
        $input = getInput();
        $fields = [];
        $params = [];
        $allowed = ['title','description','event_name','discount_percent','discount_amount','plan_id','start_date','end_date','promo_code','max_uses','status'];
        foreach ($allowed as $f) {
            if (isset($input[$f])) {
                $fields[] = "$f = ?";
                $params[] = is_string($input[$f]) ? sanitize($input[$f]) : $input[$f];
            }
        }
        if (empty($fields)) sendError('No fields to update.');
        $params[] = $id;
        $pdo->prepare("UPDATE offers SET " . implode(',', $fields) . " WHERE id = ?")->execute($params);
        sendSuccess('Offer updated successfully');
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Offer ID required.');
        $pdo->prepare("DELETE FROM offers WHERE id = ?")->execute([$id]);
        sendSuccess('Offer deleted successfully');
        break;

    default:
        sendError('Method not allowed', 405);
}
