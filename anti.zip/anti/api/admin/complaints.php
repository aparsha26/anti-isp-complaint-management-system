<?php
require_once '../config.php';
requireAuth('admin');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $status = sanitize($_GET['status'] ?? '');
        $priority = sanitize($_GET['priority'] ?? '');
        $search = sanitize($_GET['search'] ?? '');
        $page = (int)($_GET['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $where = 'WHERE 1=1';
        $params = [];
        if ($status)   { $where .= ' AND c.status = ?';   $params[] = $status; }
        if ($priority) { $where .= ' AND c.priority = ?'; $params[] = $priority; }
        if ($search)   { $where .= ' AND (c.subject LIKE ? OR u.name LIKE ? OR c.ticket_id LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }

        $count = $pdo->prepare("SELECT COUNT(*) FROM complaints c JOIN users u ON c.user_id=u.id $where");
        $count->execute($params);
        $total = $count->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT c.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
                   p.name as provider_name
            FROM complaints c
            JOIN users u ON c.user_id = u.id
            LEFT JOIN users p ON c.assigned_to = p.id
            $where
            ORDER BY FIELD(c.priority,'urgent','high','medium','low'), c.created_at DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmt->execute($params);

        sendSuccess('Complaints retrieved', [
            'complaints' => $stmt->fetchAll(),
            'pagination' => ['total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => ceil($total/$limit)]
        ]);
        break;

    case 'PUT':
        // Admin updates complaint (assign, change status, etc.)
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Complaint ID required.');
        $input = getInput();
        $fields = []; $params = [];
        $allowed = ['status','priority','assigned_to','resolution_notes'];
        foreach ($allowed as $f) {
            if (isset($input[$f])) { $fields[] = "$f = ?"; $params[] = sanitize($input[$f]); }
        }
        if (empty($fields)) sendError('No fields to update.');
        $params[] = $id;
        $pdo->prepare("UPDATE complaints SET " . implode(',', $fields) . " WHERE id = ?")->execute($params);
        sendSuccess('Complaint updated successfully');
        break;

    default:
        sendError('Method not allowed', 405);
}
