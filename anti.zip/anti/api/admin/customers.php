<?php
require_once '../config.php';
requireAuth('admin');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'stats') {
            $total = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
            $active = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer' AND status='active'")->fetchColumn();
            $suspended = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer' AND status='suspended'")->fetchColumn();
            $new_this_month = $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer' AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetchColumn();
            sendSuccess('Stats retrieved', ['stats' => compact('total','active','suspended','new_this_month')]);
        }

        // Search/filter customers
        $search = sanitize($_GET['search'] ?? '');
        $status = sanitize($_GET['status'] ?? '');
        $page = (int)($_GET['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $where = "WHERE u.role = 'customer'";
        $params = [];
        if ($search) {
            $where .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
            $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%";
        }
        if ($status) {
            $where .= " AND u.status = ?";
            $params[] = $status;
        }

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM users u $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT u.id, u.name, u.email, u.phone, u.address, u.city, u.state,
                   u.referral_code, u.status, u.created_at,
                   p.name as plan_name, s.end_date as plan_expiry, s.status as sub_status
            FROM users u
            LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'active'
            LEFT JOIN plans p ON p.id = s.plan_id
            $where
            ORDER BY u.created_at DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmt->execute($params);
        $customers = $stmt->fetchAll();

        sendSuccess('Customers retrieved', [
            'customers' => $customers,
            'pagination' => ['total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => ceil($total/$limit)]
        ]);
        break;

    case 'POST':
        // Create new customer
        $input = getInput();
        $name = sanitize($input['name'] ?? '');
        $email = sanitize($input['email'] ?? '');
        $phone = sanitize($input['phone'] ?? '');
        $password = $input['password'] ?? 'cust123';
        $address = sanitize($input['address'] ?? '');
        $city = sanitize($input['city'] ?? '');
        $state = sanitize($input['state'] ?? '');
        $pincode = sanitize($input['pincode'] ?? '');

        if (empty($name) || empty($email)) sendError('Name and email are required.');

        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) sendError('Email already registered.');

        $refCode = generateReferralCode($name);
        $stmt = $pdo->prepare("INSERT INTO users (name,email,phone,password,role,address,city,state,pincode,referral_code,status) VALUES (?,?,?,?,?,?,?,?,?,?,'active')");
        $stmt->execute([$name,$email,$phone,hashPassword($password),'customer',$address,$city,$state,$pincode,$refCode]);
        sendSuccess('Customer created successfully', ['id' => $pdo->lastInsertId()], 201);
        break;

    case 'PUT':
        // Update customer
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Customer ID required.');
        $input = getInput();

        $fields = [];
        $params = [];
        $allowed = ['name','email','phone','address','city','state','pincode','status'];
        foreach ($allowed as $f) {
            if (isset($input[$f])) {
                $fields[] = "$f = ?";
                $params[] = sanitize($input[$f]);
            }
        }
        if (isset($input['password']) && !empty($input['password'])) {
            $fields[] = "password = ?";
            $params[] = hashPassword($input['password']);
        }
        if (empty($fields)) sendError('No fields to update.');
        $params[] = $id;
        $stmt = $pdo->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = ? AND role = 'customer'");
        $stmt->execute($params);
        sendSuccess('Customer updated successfully');
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Customer ID required.');
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'customer'");
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) sendError('Customer not found.', 404);
        sendSuccess('Customer deleted successfully');
        break;

    default:
        sendError('Method not allowed', 405);
}
