<?php
require_once '../config.php';
requireAuth('customer');
$userId = $_SESSION['user_id'];

$user = $pdo->prepare("SELECT referral_code FROM users WHERE id=?");
$user->execute([$userId]);
$user = $user->fetch();

// My referrals (people I referred)
$referred = $pdo->query("
    SELECT r.*, u.name as referred_name, u.email as referred_email, r.created_at
    FROM referrals r
    JOIN users u ON r.referred_id = u.id
    WHERE r.referrer_id = $userId
    ORDER BY r.created_at DESC
")->fetchAll();

$totalEarned  = array_sum(array_column(array_filter($referred, fn($r) => $r['status']==='credited'), 'reward_amount'));
$pendingReward = array_sum(array_column(array_filter($referred, fn($r) => $r['status']==='pending'), 'reward_amount'));

sendSuccess('Referral data retrieved', [
    'referral_code'  => $user['referral_code'],
    'referred'       => $referred,
    'total_referrals'=> count($referred),
    'total_earned'   => $totalEarned,
    'pending_reward' => $pendingReward,
    'reward_per_ref' => 100,
]);
