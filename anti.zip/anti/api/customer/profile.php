<?php
require_once '../config.php';
requireAuth('customer');
$userId = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("SELECT id,name,email,phone,address,city,state,pincode,referral_code,created_at FROM users WHERE id=?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    // Active subscription
    $sub = $pdo->prepare("SELECT s.*,p.name as plan_name,p.speed,p.data_limit,p.upload_speed FROM subscriptions s JOIN plans p ON s.plan_id=p.id WHERE s.user_id=? AND s.status='active' ORDER BY s.created_at DESC LIMIT 1");
    $sub->execute([$userId]);
    $subscription = $sub->fetch();

    // Payment history
    $pays = $pdo->prepare("SELECT pay.*,p.name as plan_name FROM payments pay LEFT JOIN plans p ON pay.plan_id=p.id WHERE pay.user_id=? ORDER BY pay.created_at DESC LIMIT 5");
    $pays->execute([$userId]);
    $payments = $pays->fetchAll();

    sendSuccess('Profile retrieved', ['user' => $user, 'subscription' => $subscription, 'recent_payments' => $payments]);

} elseif ($method === 'PUT') {
    $input = getInput();
    $fields = []; $params = [];
    $allowed = ['name','phone','address','city','state','pincode'];
    foreach ($allowed as $f) {
        if (isset($input[$f])) { $fields[] = "$f=?"; $params[] = sanitize($input[$f]); }
    }
    if (isset($input['password']) && strlen($input['password']) >= 6) {
        $fields[] = "password=?";
        $params[] = hashPassword($input['password']);
    }
    if (empty($fields)) sendError('No fields to update.');
    $params[] = $userId;
    $pdo->prepare("UPDATE users SET " . implode(',', $fields) . " WHERE id=?")->execute($params);
    sendSuccess('Profile updated successfully');
} else {
    sendError('Method not allowed', 405);
}
