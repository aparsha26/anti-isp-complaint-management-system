<?php
require_once '../config.php';

// Plans are public — no auth required for GET
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $plans = $pdo->query("SELECT * FROM plans WHERE status='active' ORDER BY price ASC")->fetchAll();

    // Get active offers
    $offers = $pdo->query("
        SELECT * FROM offers 
        WHERE status='active' AND start_date <= CURDATE() AND end_date >= CURDATE()
        ORDER BY discount_percent DESC
    ")->fetchAll();

    // Map offers to plans
    $offerMap = [];
    foreach ($offers as $offer) {
        if ($offer['plan_id']) {
            $offerMap[$offer['plan_id']] = $offer;
        }
    }

    foreach ($plans as &$plan) {
        $plan['features_arr'] = $plan['features'] ? explode(',', $plan['features']) : [];
        $plan['offer'] = $offerMap[$plan['id']] ?? null;
        // Calculate discounted price
        if ($plan['offer']) {
            if ($plan['offer']['discount_percent']) {
                $plan['discounted_price'] = round($plan['price'] * (1 - $plan['offer']['discount_percent']/100), 2);
            } elseif ($plan['offer']['discount_amount']) {
                $plan['discounted_price'] = max(0, $plan['price'] - $plan['offer']['discount_amount']);
            }
        }
    }

    sendSuccess('Plans retrieved', ['plans' => $plans, 'global_offers' => array_values(array_filter($offers, fn($o) => !$o['plan_id']))]);
} elseif ($method === 'POST') {
    // Subscribe to plan
    requireAuth('customer');
    $input  = getInput();
    $planId = (int)($input['plan_id'] ?? 0);
    $userId = $_SESSION['user_id'];

    if (!$planId) sendError('Plan ID required.');

    $plan = $pdo->prepare("SELECT * FROM plans WHERE id=? AND status='active'");
    $plan->execute([$planId]);
    $plan = $plan->fetch();
    if (!$plan) sendError('Plan not found or inactive.');

    // Cancel any existing active subscription
    $pdo->prepare("UPDATE subscriptions SET status='cancelled' WHERE user_id=? AND status='active'")->execute([$userId]);

    // Create new subscription
    $stmt = $pdo->prepare("INSERT INTO subscriptions (user_id,plan_id,start_date,end_date,amount_paid,status) VALUES (?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL ? DAY),?,'active')");
    $stmt->execute([$userId, $planId, $plan['validity_days'], $plan['price']]);

    sendSuccess('Subscribed to plan successfully', ['subscription_id' => $pdo->lastInsertId(), 'plan' => $plan], 201);
} else {
    sendError('Method not allowed', 405);
}
