<?php
require_once '../config.php';
requireAuth('customer');

$method = $_SERVER['REQUEST_METHOD'];
$userId = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->prepare("
            SELECT c.*, 
                   GROUP_CONCAT(CONCAT(ca.action_type,'::',ca.notes,'::',ca.created_at) ORDER BY ca.created_at DESC SEPARATOR '||') as actions_raw
            FROM complaints c
            LEFT JOIN complaint_actions ca ON ca.complaint_id=c.id
            WHERE c.user_id=?
            GROUP BY c.id
            ORDER BY c.created_at DESC
        ");
        $stmt->execute([$userId]);
        $complaints = $stmt->fetchAll();

        foreach ($complaints as &$c) {
            $c['actions'] = [];
            if ($c['actions_raw']) {
                foreach (explode('||', $c['actions_raw']) as $a) {
                    $parts = explode('::', $a);
                    if (count($parts) >= 3) {
                        $c['actions'][] = ['type' => $parts[0], 'notes' => $parts[1], 'at' => $parts[2]];
                    }
                }
            }
            unset($c['actions_raw']);
        }
        sendSuccess('Complaints retrieved', ['complaints' => $complaints]);
        break;

    case 'POST':
        $input    = getInput();
        $category = sanitize($input['category'] ?? 'other');
        $subject  = sanitize($input['subject'] ?? '');
        $desc     = sanitize($input['description'] ?? '');
        $priority = sanitize($input['priority'] ?? 'medium');

        if (empty($subject) || empty($desc)) sendError('Subject and description are required.');
        if (!in_array($category, ['connectivity','speed','billing','installation','hardware','other'])) $category = 'other';
        if (!in_array($priority, ['low','medium','high','urgent'])) $priority = 'medium';

        $ticketId = generateTicketId();

        $stmt = $pdo->prepare("INSERT INTO complaints (ticket_id,user_id,category,subject,description,priority,status) VALUES (?,?,?,?,?,?,'open')");
        $stmt->execute([$ticketId,$userId,$category,$subject,$desc,$priority]);

        sendSuccess('Complaint submitted successfully! Your ticket ID is: ' . $ticketId, [
            'ticket_id'    => $ticketId,
            'complaint_id' => $pdo->lastInsertId()
        ], 201);
        break;

    default:
        sendError('Method not allowed', 405);
}
