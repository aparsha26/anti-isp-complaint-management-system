<?php
require_once '../config.php';
requireAuth('customer');

$method = $_SERVER['REQUEST_METHOD'];
$userId = $_SESSION['user_id'];

if ($method === 'POST') {
    $input  = getInput();
    $planId = (int)($input['plan_id'] ?? 0);
    $amount = (float)($input['amount'] ?? 0);
    $method_pay = sanitize($input['method'] ?? '');
    $promoCode  = strtoupper(sanitize($input['promo_code'] ?? ''));

    if (!$planId || $amount <= 0 || empty($method_pay)) sendError('Plan, amount, and payment method are required.');
    if (!in_array($method_pay, ['card','upi','netbanking','wallet'])) sendError('Invalid payment method.');

    // Validate promo code
    $discount = 0;
    if ($promoCode) {
        $offerStmt = $pdo->prepare("SELECT * FROM offers WHERE promo_code=? AND status='active' AND start_date<=CURDATE() AND end_date>=CURDATE() LIMIT 1");
        $offerStmt->execute([$promoCode]);
        $offer = $offerStmt->fetch();
        if ($offer) {
            if ($offer['discount_percent']) $discount = $amount * $offer['discount_percent'] / 100;
            elseif ($offer['discount_amount']) $discount = min($offer['discount_amount'], $amount);
            // Update used count
            $pdo->prepare("UPDATE offers SET used_count=used_count+1 WHERE id=?")->execute([$offer['id']]);
        } else {
            sendError('Invalid or expired promo code.');
        }
    }

    $finalAmount = max(0, $amount - $discount);
    $txnId = generateTxnId();

    // Simulate payment processing (in real app, integrate Razorpay/PayU)
    $payStatus = 'success'; // Simulated

    // Record payment
    $payStmt = $pdo->prepare("INSERT INTO payments (user_id,plan_id,amount,method,transaction_id,status) VALUES (?,?,?,?,?,?)");
    $payStmt->execute([$userId, $planId, $finalAmount, $method_pay, $txnId, $payStatus]);
    $payId = $pdo->lastInsertId();

    if ($payStatus === 'success') {
        // Get plan details
        $plan = $pdo->prepare("SELECT * FROM plans WHERE id=?");
        $plan->execute([$planId]);
        $plan = $plan->fetch();

        // Cancel existing subscription
        $pdo->prepare("UPDATE subscriptions SET status='cancelled' WHERE user_id=? AND status='active'")->execute([$userId]);

        // Create subscription
        $subStmt = $pdo->prepare("INSERT INTO subscriptions (user_id,plan_id,start_date,end_date,amount_paid,status) VALUES (?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL ? DAY),?,'active')");
        $subStmt->execute([$userId,$planId,$plan['validity_days'],$finalAmount]);
        $subId = $pdo->lastInsertId();

        // Update payment with subscription
        $pdo->prepare("UPDATE payments SET subscription_id=? WHERE id=?")->execute([$subId, $payId]);

        sendSuccess('Payment successful! Plan activated.', [
            'transaction_id' => $txnId,
            'amount'         => $finalAmount,
            'discount'       => $discount,
            'plan'           => $plan['name'],
            'valid_till'     => date('Y-m-d', strtotime("+{$plan['validity_days']} days")),
        ]);
    } else {
        sendError('Payment failed. Please try again.', 402);
    }
} elseif ($method === 'GET') {
    // Payment history
    $stmt = $pdo->prepare("
        SELECT pay.*, p.name as plan_name
        FROM payments pay
        LEFT JOIN plans p ON pay.plan_id = p.id
        WHERE pay.user_id = ?
        ORDER BY pay.created_at DESC
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    sendSuccess('Payment history', ['payments' => $stmt->fetchAll()]);
} else {
    sendError('Method not allowed', 405);
}
