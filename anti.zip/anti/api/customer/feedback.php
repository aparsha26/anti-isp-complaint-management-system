<?php
require_once '../config.php';
requireAuth('customer');

$method = $_SERVER['REQUEST_METHOD'];
$userId = $_SESSION['user_id'];

if ($method === 'POST') {
    $input    = getInput();
    $rating   = (int)($input['rating'] ?? 0);
    $category = sanitize($input['category'] ?? 'overall');
    $comment  = sanitize($input['comment'] ?? '');

    if ($rating < 1 || $rating > 5) sendError('Rating must be between 1 and 5.');
    if (!in_array($category, ['speed','support','billing','overall','installation'])) $category = 'overall';

    $stmt = $pdo->prepare("INSERT INTO feedback (user_id,rating,category,comment) VALUES (?,?,?,?)");
    $stmt->execute([$userId,$rating,$category,$comment]);
    sendSuccess('Thank you for your feedback!', ['feedback_id' => $pdo->lastInsertId()], 201);

} elseif ($method === 'GET') {
    // Get public testimonials
    $testimonials = $pdo->query("
        SELECT f.rating, f.category, f.comment, f.created_at, u.name
        FROM feedback f JOIN users u ON f.user_id=u.id
        WHERE f.is_public=1
        ORDER BY f.created_at DESC LIMIT 20
    ")->fetchAll();

    $avgRating = $pdo->query("SELECT AVG(rating) FROM feedback")->fetchColumn();
    $totalReviews = $pdo->query("SELECT COUNT(*) FROM feedback")->fetchColumn();

    sendSuccess('Feedback retrieved', [
        'testimonials' => $testimonials,
        'avg_rating'   => round($avgRating, 1),
        'total'        => $totalReviews
    ]);
} else {
    sendError('Method not allowed', 405);
}
