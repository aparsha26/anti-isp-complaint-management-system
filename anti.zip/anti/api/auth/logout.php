<?php
require_once '../config.php';

session_destroy();
sendSuccess('Logged out successfully.');
