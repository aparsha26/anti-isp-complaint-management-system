<?php
require_once '../config.php';

if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT id, name, email, phone, role, referral_code, status FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user && $user['status'] === 'active') {
        sendSuccess('Authenticated', ['user' => $user, 'role' => $_SESSION['role']]);
    } else {
        session_destroy();
        sendError('Session expired or account suspended.', 401);
    }
} else {
    sendError('Not authenticated.', 401);
}
