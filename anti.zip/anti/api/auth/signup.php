<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$input = getInput();
$name     = sanitize($input['name'] ?? '');
$email    = sanitize($input['email'] ?? '');
$phone    = sanitize($input['phone'] ?? '');
$password = $input['password'] ?? '';
$address  = sanitize($input['address'] ?? '');
$city     = sanitize($input['city'] ?? '');
$state    = sanitize($input['state'] ?? '');
$pincode  = sanitize($input['pincode'] ?? '');
$ref_code = sanitize($input['referral_code'] ?? '');

// Validate required fields
if (empty($name) || empty($email) || empty($phone) || empty($password)) {
    sendError('Name, email, phone, and password are required.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendError('Invalid email format.');
}

if (strlen($password) < 6) {
    sendError('Password must be at least 6 characters.');
}

// Check if email already exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    sendError('Email already registered. Please login.');
}

// Generate referral code
$myReferralCode = generateReferralCode($name);
$hashedPassword = hashPassword($password);

// Check referred_by
$referredBy = null;
$referrerId = null;
if (!empty($ref_code)) {
    $refStmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ? LIMIT 1");
    $refStmt->execute([$ref_code]);
    $refUser = $refStmt->fetch();
    if ($refUser) {
        $referredBy = $ref_code;
        $referrerId = $refUser['id'];
    }
}

// Insert new customer
$stmt = $pdo->prepare("
    INSERT INTO users (name, email, phone, password, role, address, city, state, pincode, referral_code, referred_by, status)
    VALUES (?, ?, ?, ?, 'customer', ?, ?, ?, ?, ?, ?, 'active')
");
$stmt->execute([$name, $email, $phone, $hashedPassword, $address, $city, $state, $pincode, $myReferralCode, $referredBy]);
$newUserId = $pdo->lastInsertId();

// Record referral reward
if ($referrerId) {
    $refInsert = $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, reward_amount, status) VALUES (?, ?, 100.00, 'pending')");
    $refInsert->execute([$referrerId, $newUserId]);
}

// Auto-login
$_SESSION['user_id']   = $newUserId;
$_SESSION['name']      = $name;
$_SESSION['email']     = $email;
$_SESSION['role']      = 'customer';
$_SESSION['logged_in'] = true;

sendSuccess('Account created successfully! Welcome to ISP Portal.', [
    'user' => [
        'id'            => $newUserId,
        'name'          => $name,
        'email'         => $email,
        'phone'         => $phone,
        'role'          => 'customer',
        'referral_code' => $myReferralCode,
    ]
], 201);
