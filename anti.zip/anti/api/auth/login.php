<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$input = getInput();
$email    = sanitize($input['email'] ?? '');
$password = $input['password'] ?? '';
$role     = sanitize($input['role'] ?? '');

if (empty($email) || empty($password) || empty($role)) {
    sendError('Email, password and role are required.');
}

if (!in_array($role, ['admin', 'provider', 'customer'])) {
    sendError('Invalid role specified.');
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = ? AND status = 'active' LIMIT 1");
$stmt->execute([$email, $role]);
$user = $stmt->fetch();

if ($user && $user['password'] === hashPassword($password)) {
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['name']      = $user['name'];
    $_SESSION['email']     = $user['email'];
    $_SESSION['role']      = $user['role'];
    $_SESSION['logged_in'] = true;

    // Get active subscription if customer
    $subscription = null;
    if ($role === 'customer') {
        $sub = $pdo->prepare("
            SELECT s.*, p.name as plan_name, p.speed, p.data_limit 
            FROM subscriptions s 
            JOIN plans p ON s.plan_id = p.id 
            WHERE s.user_id = ? AND s.status = 'active' 
            ORDER BY s.created_at DESC LIMIT 1
        ");
        $sub->execute([$user['id']]);
        $subscription = $sub->fetch();
    }

    sendSuccess('Login successful', [
        'user' => [
            'id'            => $user['id'],
            'name'          => $user['name'],
            'email'         => $user['email'],
            'phone'         => $user['phone'],
            'role'          => $user['role'],
            'referral_code' => $user['referral_code'],
            'status'        => $user['status'],
        ],
        'subscription' => $subscription
    ]);
} else {
    sendError('Invalid email or password.', 401);
}
