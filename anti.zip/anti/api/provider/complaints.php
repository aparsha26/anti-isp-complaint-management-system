<?php
require_once '../config.php';
requireAuth(['admin','provider']);

$method = $_SERVER['REQUEST_METHOD'];
$providerId = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        $status   = sanitize($_GET['status'] ?? '');
        $priority = sanitize($_GET['priority'] ?? '');
        $page     = (int)($_GET['page'] ?? 1);
        $limit    = 10;
        $offset   = ($page - 1) * $limit;

        $where  = 'WHERE 1=1';
        $params = [];

        // Providers only see assigned or unassigned complaints
        if ($_SESSION['role'] === 'provider') {
            $where .= ' AND (c.assigned_to = ? OR c.assigned_to IS NULL)';
            $params[] = $providerId;
        }
        if ($status)   { $where .= ' AND c.status = ?';   $params[] = $status; }
        if ($priority) { $where .= ' AND c.priority = ?'; $params[] = $priority; }

        $count = $pdo->prepare("SELECT COUNT(*) FROM complaints c $where");
        $count->execute($params);
        $total = $count->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT c.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
                   p.name as provider_name
            FROM complaints c
            JOIN users u ON c.user_id = u.id
            LEFT JOIN users p ON c.assigned_to = p.id
            $where
            ORDER BY FIELD(c.priority,'urgent','high','medium','low'), c.created_at DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmt->execute($params);
        $complaints = $stmt->fetchAll();

        // Get actions for each complaint
        foreach ($complaints as &$c) {
            $act = $pdo->prepare("
                SELECT ca.*, u.name as provider_name FROM complaint_actions ca 
                JOIN users u ON ca.provider_id=u.id 
                WHERE ca.complaint_id=? ORDER BY ca.created_at DESC
            ");
            $act->execute([$c['id']]);
            $c['actions'] = $act->fetchAll();
        }

        sendSuccess('Complaints retrieved', [
            'complaints' => $complaints,
            'pagination' => ['total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => ceil($total/$limit)]
        ]);
        break;

    case 'POST':
        // Add action to complaint
        $input = getInput();
        $complaintId = (int)($input['complaint_id'] ?? 0);
        $actionType  = sanitize($input['action_type'] ?? 'note');
        $notes       = sanitize($input['notes'] ?? '');

        if (!$complaintId || empty($notes)) sendError('Complaint ID and notes are required.');

        // Insert action
        $stmt = $pdo->prepare("INSERT INTO complaint_actions (complaint_id, provider_id, action_type, notes) VALUES (?,?,?,?)");
        $stmt->execute([$complaintId, $providerId, $actionType, $notes]);

        // Update complaint status and assign to this provider
        $newStatus = $actionType === 'fixed' ? 'resolved' : 'in_progress';
        $pdo->prepare("UPDATE complaints SET status=?, assigned_to=? WHERE id=?")
            ->execute([$newStatus, $providerId, $complaintId]);

        sendSuccess('Action recorded successfully');
        break;

    case 'PUT':
        // Update complaint status
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Complaint ID required.');
        $input  = getInput();
        $status = sanitize($input['status'] ?? '');
        $prio   = sanitize($input['priority'] ?? '');
        $assignTo = isset($input['assigned_to']) ? (int)$input['assigned_to'] : null;

        $fields = []; $params = [];
        if ($status)   { $fields[] = 'status = ?';     $params[] = $status; }
        if ($prio)     { $fields[] = 'priority = ?';   $params[] = $prio; }
        if ($assignTo) { $fields[] = 'assigned_to = ?'; $params[] = $assignTo; }
        if (isset($input['resolution_notes'])) { $fields[] = 'resolution_notes = ?'; $params[] = sanitize($input['resolution_notes']); }

        if (empty($fields)) sendError('No fields to update.');
        $params[] = $id;
        $pdo->prepare("UPDATE complaints SET " . implode(',', $fields) . " WHERE id = ?")->execute($params);
        sendSuccess('Complaint updated');
        break;

    default:
        sendError('Method not allowed', 405);
}
