<?php
require_once '../config.php';
requireAuth(['admin','provider']);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Service zones with status
        $zones = $pdo->query("
            SELECT sz.*, u.name as provider_name
            FROM service_zones sz
            LEFT JOIN users u ON sz.provider_id = u.id
            ORDER BY sz.status ASC, sz.zone_name ASC
        ")->fetchAll();

        // Stats
        $stats = [
            'total_zones'       => $pdo->query("SELECT COUNT(*) FROM service_zones")->fetchColumn(),
            'operational'       => $pdo->query("SELECT COUNT(*) FROM service_zones WHERE status='operational'")->fetchColumn(),
            'maintenance'       => $pdo->query("SELECT COUNT(*) FROM service_zones WHERE status='maintenance'")->fetchColumn(),
            'outage'            => $pdo->query("SELECT COUNT(*) FROM service_zones WHERE status='outage'")->fetchColumn(),
            'active_customers'  => $pdo->query("SELECT COUNT(*) FROM users WHERE role='customer' AND status='active'")->fetchColumn(),
            'open_complaints'   => $pdo->query("SELECT COUNT(*) FROM complaints WHERE status IN ('open','in_progress')")->fetchColumn(),
            'resolved_today'    => $pdo->query("SELECT COUNT(*) FROM complaints WHERE status='resolved' AND DATE(updated_at)=CURDATE()")->fetchColumn(),
        ];

        // Provider list
        $providers = $pdo->query("SELECT id, name, email FROM users WHERE role='provider' AND status='active'")->fetchAll();

        sendSuccess('Services retrieved', ['zones' => $zones, 'stats' => $stats, 'providers' => $providers]);
        break;

    case 'PUT':
        // Update zone status
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendError('Zone ID required.');
        $input  = getInput();
        $status = sanitize($input['status'] ?? '');
        $providerId = isset($input['provider_id']) ? (int)$input['provider_id'] : null;

        if (!in_array($status, ['operational','maintenance','outage'])) sendError('Invalid status.');

        $fields = ['status = ?', 'last_checked = NOW()'];
        $params = [$status];
        if ($providerId) { $fields[] = 'provider_id = ?'; $params[] = $providerId; }
        $params[] = $id;
        $pdo->prepare("UPDATE service_zones SET " . implode(',', $fields) . " WHERE id = ?")->execute($params);
        sendSuccess('Zone status updated');
        break;

    default:
        sendError('Method not allowed', 405);
}
