<?php
// =============================================
// ISP Management System - Core Config
// =============================================

// CORS & Content headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'isp_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Create PDO connection
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

// =============================================
// Helper Functions
// =============================================

function sendResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

function sendSuccess($message, $data = [], $status = 200) {
    sendResponse(array_merge(['success' => true, 'message' => $message], $data), $status);
}

function sendError($message, $status = 400) {
    sendResponse(['success' => false, 'message' => $message], $status);
}

function requireAuth($role = null) {
    if (!isset($_SESSION['user_id'])) {
        sendError('Unauthorized. Please login first.', 401);
    }
    if ($role !== null) {
        if (is_array($role)) {
            if (!in_array($_SESSION['role'], $role)) {
                sendError('Access denied. Insufficient permissions.', 403);
            }
        } else {
            if ($_SESSION['role'] !== $role) {
                sendError('Access denied. Insufficient permissions.', 403);
            }
        }
    }
}

function getInput() {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    return $input;
}

function sanitize($str) {
    return htmlspecialchars(strip_tags(trim($str)));
}

function generateTicketId() {
    return 'TKT-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
}

function generateReferralCode($name) {
    return strtoupper(substr($name, 0, 3)) . rand(1000, 9999);
}

function hashPassword($password) {
    return hash('sha256', $password);
}

function generateTxnId() {
    return 'TXN' . time() . rand(100, 999);
}
