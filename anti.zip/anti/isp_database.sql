-- ============================================================
--  ISP MANAGEMENT SYSTEM — phpMyAdmin Import File
--  Database  : isp_db
--  Charset   : utf8mb4 / utf8mb4_unicode_ci
--  Generated : 2026-04-16
--  HOW TO USE:
--    1. Open phpMyAdmin
--    2. Click "Import" tab
--    3. Choose this file → click "Go"
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+05:30";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- ============================================================
-- CREATE & SELECT DATABASE
-- ============================================================

CREATE DATABASE IF NOT EXISTS `isp_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `isp_db`;

-- ============================================================
-- DISABLE FOREIGN KEY CHECKS DURING IMPORT
-- ============================================================
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- DROP TABLES (reverse dependency order)
-- ============================================================
DROP TABLE IF EXISTS `complaint_actions`;
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `feedback`;
DROP TABLE IF EXISTS `referrals`;
DROP TABLE IF EXISTS `offers`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `subscriptions`;
DROP TABLE IF EXISTS `service_zones`;
DROP TABLE IF EXISTS `plans`;
DROP TABLE IF EXISTS `users`;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE `users` (
  `id`            INT            NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(100)   NOT NULL,
  `email`         VARCHAR(100)   NOT NULL,
  `phone`         VARCHAR(20)    DEFAULT NULL,
  `password`      VARCHAR(255)   NOT NULL,
  `role`          ENUM('admin','provider','customer') NOT NULL DEFAULT 'customer',
  `address`       TEXT           DEFAULT NULL,
  `city`          VARCHAR(100)   DEFAULT NULL,
  `state`         VARCHAR(100)   DEFAULT NULL,
  `pincode`       VARCHAR(10)    DEFAULT NULL,
  `referral_code` VARCHAR(20)    DEFAULT NULL,
  `referred_by`   VARCHAR(20)    DEFAULT NULL,
  `avatar`        VARCHAR(255)   DEFAULT NULL,
  `status`        ENUM('active','inactive','suspended') DEFAULT 'active',
  `created_at`    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email`         (`email`),
  UNIQUE KEY `uq_users_referral_code` (`referral_code`),
  KEY `idx_users_role`   (`role`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Stores admin, provider and customer accounts';

-- ============================================================
-- TABLE: plans
-- ============================================================
CREATE TABLE `plans` (
  `id`            INT            NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(100)   NOT NULL,
  `speed`         VARCHAR(50)    NOT NULL,
  `upload_speed`  VARCHAR(50)    DEFAULT NULL,
  `data_limit`    VARCHAR(50)    DEFAULT NULL,
  `price`         DECIMAL(10,2)  NOT NULL,
  `validity_days` INT            NOT NULL DEFAULT 30,
  `description`   TEXT           DEFAULT NULL,
  `features`      TEXT           DEFAULT NULL,
  `badge`         VARCHAR(50)    DEFAULT NULL,
  `status`        ENUM('active','inactive') DEFAULT 'active',
  `created_at`    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_plans_status` (`status`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Internet subscription plans';

-- ============================================================
-- TABLE: subscriptions
-- ============================================================
CREATE TABLE `subscriptions` (
  `id`           INT           NOT NULL AUTO_INCREMENT,
  `user_id`      INT           NOT NULL,
  `plan_id`      INT           NOT NULL,
  `start_date`   DATE          NOT NULL,
  `end_date`     DATE          NOT NULL,
  `amount_paid`  DECIMAL(10,2) DEFAULT NULL,
  `status`       ENUM('active','expired','cancelled','pending') DEFAULT 'active',
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sub_user`   (`user_id`),
  KEY `idx_sub_plan`   (`plan_id`),
  KEY `idx_sub_status` (`status`),
  CONSTRAINT `fk_sub_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sub_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Customer plan subscriptions';

-- ============================================================
-- TABLE: payments
-- ============================================================
CREATE TABLE `payments` (
  `id`              INT           NOT NULL AUTO_INCREMENT,
  `user_id`         INT           NOT NULL,
  `plan_id`         INT           DEFAULT NULL,
  `subscription_id` INT           DEFAULT NULL,
  `amount`          DECIMAL(10,2) NOT NULL,
  `method`          ENUM('card','upi','netbanking','wallet') NOT NULL,
  `transaction_id`  VARCHAR(100)  DEFAULT NULL,
  `gateway_ref`     VARCHAR(200)  DEFAULT NULL,
  `notes`           TEXT          DEFAULT NULL,
  `status`          ENUM('pending','success','failed','refunded') DEFAULT 'pending',
  `created_at`      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pay_txn`       (`transaction_id`),
  KEY `idx_pay_user`   (`user_id`),
  KEY `idx_pay_plan`   (`plan_id`),
  KEY `idx_pay_status` (`status`),
  CONSTRAINT `fk_pay_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pay_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='All payment transactions';

-- ============================================================
-- TABLE: complaints
-- ============================================================
CREATE TABLE `complaints` (
  `id`               INT          NOT NULL AUTO_INCREMENT,
  `ticket_id`        VARCHAR(20)  NOT NULL,
  `user_id`          INT          NOT NULL,
  `category`         ENUM('connectivity','speed','billing','installation','hardware','other') DEFAULT 'other',
  `subject`          VARCHAR(200) NOT NULL,
  `description`      TEXT         NOT NULL,
  `attachment`       VARCHAR(255) DEFAULT NULL,
  `priority`         ENUM('low','medium','high','urgent') DEFAULT 'medium',
  `status`           ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
  `assigned_to`      INT          DEFAULT NULL,
  `resolution_notes` TEXT         DEFAULT NULL,
  `created_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ticket_id`        (`ticket_id`),
  KEY `idx_comp_user`     (`user_id`),
  KEY `idx_comp_assigned` (`assigned_to`),
  KEY `idx_comp_status`   (`status`),
  CONSTRAINT `fk_comp_user`     FOREIGN KEY (`user_id`)     REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Customer support tickets / complaints';

-- ============================================================
-- TABLE: complaint_actions
-- ============================================================
CREATE TABLE `complaint_actions` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `complaint_id` INT          NOT NULL,
  `provider_id`  INT          NOT NULL,
  `action_type`  ENUM('visited','fixed','escalated','note','called') DEFAULT 'note',
  `notes`        TEXT         NOT NULL,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ca_complaint` (`complaint_id`),
  KEY `idx_ca_provider`  (`provider_id`),
  CONSTRAINT `fk_ca_complaint` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ca_provider`  FOREIGN KEY (`provider_id`)  REFERENCES `users`      (`id`) ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Actions / notes logged against a complaint by providers';

-- ============================================================
-- TABLE: feedback
-- ============================================================
CREATE TABLE `feedback` (
  `id`         INT       NOT NULL AUTO_INCREMENT,
  `user_id`    INT       NOT NULL,
  `rating`     TINYINT   NOT NULL COMMENT '1-5 star rating',
  `category`   ENUM('speed','support','billing','overall','installation') DEFAULT 'overall',
  `comment`    TEXT      DEFAULT NULL,
  `is_public`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fb_user`   (`user_id`),
  KEY `idx_fb_rating` (`rating`),
  CONSTRAINT `fk_fb_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_rating` CHECK (`rating` >= 1 AND `rating` <= 5)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Service ratings and feedback from customers';

-- ============================================================
-- TABLE: offers
-- ============================================================
CREATE TABLE `offers` (
  `id`               INT           NOT NULL AUTO_INCREMENT,
  `title`            VARCHAR(150)  NOT NULL,
  `description`      TEXT          DEFAULT NULL,
  `event_name`       VARCHAR(100)  DEFAULT NULL,
  `discount_percent` DECIMAL(5,2)  DEFAULT NULL,
  `discount_amount`  DECIMAL(10,2) DEFAULT NULL,
  `plan_id`          INT           DEFAULT NULL,
  `start_date`       DATE          NOT NULL,
  `end_date`         DATE          NOT NULL,
  `promo_code`       VARCHAR(50)   DEFAULT NULL,
  `max_uses`         INT           NOT NULL DEFAULT 0,
  `used_count`       INT           NOT NULL DEFAULT 0,
  `status`           ENUM('active','inactive','expired') DEFAULT 'active',
  `created_at`       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_promo_code`   (`promo_code`),
  KEY `idx_offer_plan`   (`plan_id`),
  KEY `idx_offer_status` (`status`),
  CONSTRAINT `fk_offer_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Festival and seasonal promotional offers';

-- ============================================================
-- TABLE: referrals
-- ============================================================
CREATE TABLE `referrals` (
  `id`            INT           NOT NULL AUTO_INCREMENT,
  `referrer_id`   INT           NOT NULL,
  `referred_id`   INT           NOT NULL,
  `reward_amount` DECIMAL(10,2) NOT NULL DEFAULT 100.00,
  `status`        ENUM('pending','credited','expired') DEFAULT 'pending',
  `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ref_referrer` (`referrer_id`),
  KEY `idx_ref_referred` (`referred_id`),
  CONSTRAINT `fk_ref_referrer` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ref_referred` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Customer referral rewards tracking';

-- ============================================================
-- TABLE: service_zones
-- ============================================================
CREATE TABLE `service_zones` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `zone_name`    VARCHAR(100) NOT NULL,
  `area`         VARCHAR(200) DEFAULT NULL,
  `provider_id`  INT          DEFAULT NULL,
  `status`       ENUM('operational','maintenance','outage') DEFAULT 'operational',
  `last_checked` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sz_provider` (`provider_id`),
  KEY `idx_sz_status`   (`status`),
  CONSTRAINT `fk_sz_provider` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Geographic service zones managed by providers';

-- ============================================================
-- RE-ENABLE FOREIGN KEY CHECKS
-- ============================================================
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- SEED DATA — USERS
-- Passwords hashed with SHA2(..., 256)
--   admin@isp.com    → admin123
--   provider@isp.com → provider123
--   tech@isp.com     → provider123
--   customers        → cust123
-- ============================================================

INSERT INTO `users`
  (`name`, `email`, `phone`, `password`, `role`, `address`, `city`, `state`, `pincode`, `referral_code`, `status`)
VALUES
-- Admin
('Super Admin',        'admin@isp.com',    '9876543210', SHA2('admin123',    256), 'admin',    NULL,                    NULL,        NULL,          NULL,     NULL,    'active'),
-- Providers
('TechCare Support',   'provider@isp.com', '9876543211', SHA2('provider123', 256), 'provider', NULL,                    NULL,        NULL,          NULL,     NULL,    'active'),
('Field Technician',   'tech@isp.com',     '9876543215', SHA2('provider123', 256), 'provider', NULL,                    NULL,        NULL,          NULL,     NULL,    'active'),
-- Customers
('Rahul Sharma',       'rahul@gmail.com',  '9876543212', SHA2('cust123',     256), 'customer', '123 MG Road',           'Bangalore', 'Karnataka',   '560001', 'REF001','active'),
('Priya Patel',        'priya@gmail.com',  '9876543213', SHA2('cust123',     256), 'customer', '456 FC Road',           'Pune',      'Maharashtra', '411001', 'REF002','active'),
('Amit Kumar',         'amit@gmail.com',   '9876543214', SHA2('cust123',     256), 'customer', '789 Park Street',       'Delhi',     'Delhi',       '110001', 'REF003','active'),
('Sneha Reddy',        'sneha@gmail.com',  '9876543216', SHA2('cust123',     256), 'customer', '321 Jubilee Hills',     'Hyderabad', 'Telangana',   '500033', 'REF004','active'),
('Vijay Nair',         'vijay@gmail.com',  '9876543217', SHA2('cust123',     256), 'customer', '654 Marine Drive',      'Mumbai',    'Maharashtra', '400001', 'REF005','active'),
('Divya Menon',        'divya@gmail.com',  '9876543218', SHA2('cust123',     256), 'customer', '22 Anna Nagar',         'Chennai',   'Tamil Nadu',  '600040', 'REF006','active'),
('Karan Singh',        'karan@gmail.com',  '9876543219', SHA2('cust123',     256), 'customer', '77 Sector 14',          'Gurgaon',   'Haryana',     '122001', 'REF007','active');

-- ============================================================
-- SEED DATA — PLANS
-- ============================================================

INSERT INTO `plans`
  (`name`, `speed`, `upload_speed`, `data_limit`, `price`, `validity_days`, `description`, `features`, `badge`)
VALUES
('Basic',       '10 Mbps',  '5 Mbps',   '100 GB',   399.00,  30, 'Perfect for light browsing and social media',         'Social Media,Email,Light Streaming,24/7 Support',              NULL),
('Standard',    '50 Mbps',  '25 Mbps',  '300 GB',   699.00,  30, 'Great for HD streaming and gaming',                   'HD Streaming,Online Gaming,Video Calls,Priority Support',      'Popular'),
('Pro',         '100 Mbps', '50 Mbps',  'Unlimited', 999.00, 30, 'High-speed unlimited for power users',                'Unlimited Data,4K Streaming,Fast Gaming,Dedicated Support',   'Best Value'),
('Ultra Fiber', '200 Mbps', '100 Mbps', 'Unlimited',1499.00, 30, 'Ultra-fast fiber for enterprises & heavy users',      'Ultra Speed,Unlimited Data,Static IP,SLA 99.9%',              'Enterprise'),
('Student Pack','25 Mbps',  '10 Mbps',  '150 GB',   499.00,  30, 'Special plan designed for students',                  'Study Tools,E-learning,Video Calls,Budget Friendly',          'Student'),
('Business Pro','300 Mbps', '150 Mbps', 'Unlimited',2499.00, 30, 'Designed for small and medium businesses',            'Dedicated Line,Static IP,SLA 99.99%,24/7 Priority Support',  'Business'),
('Night Surfer','100 Mbps', '50 Mbps',  '500 GB',   599.00,  30, 'Free unlimited data midnight to 6 AM every day',     'Night Unlimited,Day Data,Gaming Ready,Budget Friendly',       'Night Deal');

-- ============================================================
-- SEED DATA — SUBSCRIPTIONS
-- user ids: Rahul=4, Priya=5, Amit=6, Sneha=7, Vijay=8, Divya=9, Karan=10
-- ============================================================

INSERT INTO `subscriptions`
  (`user_id`, `plan_id`, `start_date`, `end_date`, `amount_paid`, `status`)
VALUES
(4,  2, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY),  699.00, 'active'),
(5,  3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY),  999.00, 'active'),
(6,  1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY),  399.00, 'active'),
(7,  4, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 1499.00, 'active'),
(8,  5, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY),  499.00, 'active'),
(9,  6, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 2499.00, 'active'),
(10, 7, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY),  599.00, 'active'),
-- expired subscriptions for history
(4,  1, DATE_SUB(CURDATE(), INTERVAL 60 DAY), DATE_SUB(CURDATE(), INTERVAL 30 DAY), 399.00, 'expired'),
(5,  2, DATE_SUB(CURDATE(), INTERVAL 60 DAY), DATE_SUB(CURDATE(), INTERVAL 30 DAY), 699.00, 'expired');

-- ============================================================
-- SEED DATA — PAYMENTS
-- ============================================================

INSERT INTO `payments`
  (`user_id`, `plan_id`, `amount`, `method`, `transaction_id`, `status`)
VALUES
(4,  2, 699.00,  'upi',        'TXN001234567', 'success'),
(5,  3, 999.00,  'card',       'TXN001234568', 'success'),
(6,  1, 399.00,  'wallet',     'TXN001234569', 'success'),
(7,  4, 1499.00, 'netbanking', 'TXN001234570', 'success'),
(8,  5, 499.00,  'upi',        'TXN001234571', 'success'),
(9,  6, 2499.00, 'card',       'TXN001234572', 'success'),
(10, 7, 599.00,  'upi',        'TXN001234573', 'success'),
-- historical payments
(4,  1, 399.00,  'wallet',     'TXN001234574', 'success'),
(5,  2, 699.00,  'card',       'TXN001234575', 'success'),
-- failed payment example
(6,  3, 999.00,  'netbanking', 'TXN001234576', 'failed');

-- ============================================================
-- SEED DATA — COMPLAINTS
-- ============================================================

INSERT INTO `complaints`
  (`ticket_id`, `user_id`, `category`, `subject`, `description`, `priority`, `status`, `assigned_to`)
VALUES
('TKT-2024-001', 4,  'connectivity', 'No internet connection since morning',      'Unable to connect since 8 AM. Modem lights showing red. Tried restarting multiple times.',                                'high',   'in_progress', 2),
('TKT-2024-002', 5,  'speed',        'Very slow internet speed',                  'Getting only 5 Mbps on a 100 Mbps plan. Running speed tests confirms slow speed.',                                         'medium', 'open',        NULL),
('TKT-2024-003', 6,  'billing',      'Double charged this month',                 'I was charged twice for the same plan in April. Please refund the extra amount.',                                           'urgent', 'open',        NULL),
('TKT-2024-004', 7,  'installation', 'New connection setup incomplete',            'Technician visited but did not install the router properly. Connection drops every hour.',                                  'high',   'resolved',    2),
('TKT-2024-005', 8,  'hardware',     'Modem malfunction',                         'The provided modem frequently disconnects. Need replacement.',                                                              'medium', 'open',        NULL),
('TKT-2024-006', 9,  'speed',        'Upload speed degraded for 3 days',          'Upload speed dropped from 150 Mbps to below 10 Mbps. All devices affected. Business operations impacted.',                 'urgent', 'in_progress', 3),
('TKT-2024-007', 10, 'connectivity', 'Random disconnections at night',            'Internet disconnects randomly between 12 AM and 4 AM every night. Night Surfer plan is completely wasted during that time.','high',   'open',        NULL),
('TKT-2024-008', 4,  'billing',      'Referral reward not credited',              'My friend signed up using my referral code REF001 two weeks ago. The reward of Rs.100 has not been credited yet.',          'low',    'closed',      2);

-- ============================================================
-- SEED DATA — COMPLAINT ACTIONS
-- ============================================================

INSERT INTO `complaint_actions`
  (`complaint_id`, `provider_id`, `action_type`, `notes`)
VALUES
(1, 2, 'called',    'Called customer. Confirmed modem lights red. Asked to restart ONT box.'),
(1, 2, 'visited',   'Visited customer premises. Found modem issue. Replaced modem unit.'),
(1, 2, 'fixed',     'Connection restored. Customer confirmed working. Ticket to be closed.'),
(4, 2, 'visited',   'Visited and properly configured the router. Set up cables correctly.'),
(4, 2, 'fixed',     'All connections verified and stable. Issue resolved.'),
(6, 3, 'called',    'Called business customer. Issue confirmed on upload side. Checking line.'),
(6, 3, 'visited',   'Visited premises. Found fiber splice degraded. Replaced splice at junction.'),
(8, 2, 'note',      'Referral verified in system. Reward of Rs.100 manually credited to wallet.');

-- ============================================================
-- SEED DATA — FEEDBACK
-- ============================================================

INSERT INTO `feedback`
  (`user_id`, `rating`, `category`, `comment`, `is_public`)
VALUES
(4,  5, 'speed',        'Excellent internet speed! Very happy with the service.',                    1),
(5,  4, 'support',      'Support team was helpful and resolved my issue quickly.',                   1),
(6,  3, 'overall',      'Service is okay but sometimes slow during peak hours.',                     1),
(7,  5, 'overall',      'Best ISP in the city! Highly recommended.',                                1),
(8,  4, 'installation', 'Installation was smooth and professional.',                                1),
(9,  5, 'speed',        'Business plan is blazing fast. Zero downtime in 3 months.',                1),
(10, 3, 'support',      'Support takes time to respond. Speed is good though.',                     1),
(4,  4, 'billing',      'Billing is transparent. No hidden charges. Appreciated.',                  1);

-- ============================================================
-- SEED DATA — OFFERS
-- ============================================================

INSERT INTO `offers`
  (`title`, `description`, `event_name`, `discount_percent`, `plan_id`, `start_date`, `end_date`, `promo_code`, `max_uses`, `status`)
VALUES
('Diwali Special Offer',  'Get 30% off on Pro plan this Diwali! Limited time offer.',          'Diwali',          30.00, 3,    CURDATE(), DATE_ADD(CURDATE(), INTERVAL 15 DAY), 'DIWALI30',   500, 'active'),
('New Year Bonanza',      'Start the new year with 20% off on any plan!',                      'New Year',        20.00, NULL, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'NEWYEAR20', 1000, 'active'),
('Student Season Sale',   'Back to school! 15% off on Student Pack.',                          'Back to School',  15.00, 5,    CURDATE(), DATE_ADD(CURDATE(), INTERVAL 45 DAY), 'STUDENT15',  300, 'active'),
('Business Booster',      'Exclusive 25% discount on Business Pro plan for new signups.',       'B2B Drive',       25.00, 6,    CURDATE(), DATE_ADD(CURDATE(), INTERVAL 20 DAY), 'BIZ25',      200, 'active'),
('Summer Splash',         'Beat the heat with unlimited data at just Rs.799 on Standard plan.', 'Summer',         NULL,  2, DATE_SUB(CURDATE(), INTERVAL 60 DAY), DATE_SUB(CURDATE(), INTERVAL 30 DAY), 'SUMMER799', 1000, 'expired');

-- ============================================================
-- SEED DATA — REFERRALS
-- ============================================================

INSERT INTO `referrals`
  (`referrer_id`, `referred_id`, `reward_amount`, `status`)
VALUES
(4, 5, 100.00, 'credited'),
(4, 6, 100.00, 'credited'),
(5, 8, 100.00, 'credited'),
(7, 9, 100.00, 'pending'),
(9,10, 100.00, 'pending');

-- ============================================================
-- SEED DATA — SERVICE ZONES
-- ============================================================

INSERT INTO `service_zones`
  (`zone_name`, `area`, `provider_id`, `status`)
VALUES
('Zone A — South Bangalore', 'Koramangala, BTM Layout, HSR Layout',        2, 'operational'),
('Zone B — North Bangalore', 'Hebbal, Yelahanka, Sahakarnagar',            2, 'operational'),
('Zone C — East Bangalore',  'Whitefield, Marathahalli, KR Puram',         3, 'maintenance'),
('Zone D — West Bangalore',  'Rajajinagar, Vijaynagar, Yeshwanthpur',      3, 'operational'),
('Zone E — Central',         'MG Road, Cubbon Park, Richmond Town',        2, 'operational'),
('Zone F — Outer Ring Road', 'Bellandur, Sarjapur, Electronic City',       3, 'outage');

-- ============================================================
-- COMMIT TRANSACTION
-- ============================================================

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- ============================================================
-- VERIFICATION QUERIES (optional — run manually to check)
-- ============================================================
-- SELECT 'users'          AS tbl, COUNT(*) AS rows FROM users;
-- SELECT 'plans'          AS tbl, COUNT(*) AS rows FROM plans;
-- SELECT 'subscriptions'  AS tbl, COUNT(*) AS rows FROM subscriptions;
-- SELECT 'payments'       AS tbl, COUNT(*) AS rows FROM payments;
-- SELECT 'complaints'     AS tbl, COUNT(*) AS rows FROM complaints;
-- SELECT 'complaint_acts' AS tbl, COUNT(*) AS rows FROM complaint_actions;
-- SELECT 'feedback'       AS tbl, COUNT(*) AS rows FROM feedback;
-- SELECT 'offers'         AS tbl, COUNT(*) AS rows FROM offers;
-- SELECT 'referrals'      AS tbl, COUNT(*) AS rows FROM referrals;
-- SELECT 'service_zones'  AS tbl, COUNT(*) AS rows FROM service_zones;

SELECT 'isp_db imported successfully!' AS status;
