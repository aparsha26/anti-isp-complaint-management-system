// =============================================
// ISP MANAGEMENT SYSTEM — GLOBAL JS UTILITIES
// =============================================

/* ---- API Base URL ---- */
const API_BASE = '../api';  // relative from portal pages

/* =============================================
   TOAST NOTIFICATIONS
   ============================================= */
function createToastContainer() {
  if (!document.getElementById('toast-container')) {
    const div = document.createElement('div');
    div.id = 'toast-container';
    document.body.appendChild(div);
  }
}

function showToast(message, type = 'info', duration = 4000) {
  createToastContainer();
  const container = document.getElementById('toast-container');
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info', warning: 'fa-triangle-exclamation' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <i class="fas ${icons[type] || icons.info} toast-icon"></i>
    <span class="toast-msg">${message}</span>
  `;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, duration);
}

/* =============================================
   LOADING OVERLAY
   ============================================= */
function showLoading(text = 'Loading...') {
  let overlay = document.getElementById('loading-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'loading-overlay';
    overlay.className = 'loading-overlay';
    overlay.innerHTML = `<div class="spinner"></div><p>${text}</p>`;
    document.body.appendChild(overlay);
  }
  overlay.querySelector('p').textContent = text;
  overlay.classList.add('active');
}

function hideLoading() {
  const overlay = document.getElementById('loading-overlay');
  if (overlay) overlay.classList.remove('active');
}

/* =============================================
   API FETCH HELPER
   ============================================= */
async function apiCall(endpoint, method = 'GET', body = null) {
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include'
  };
  if (body && method !== 'GET') {
    options.body = JSON.stringify(body);
  }
  try {
    const url = endpoint.startsWith('http') ? endpoint : `${getApiBase()}${endpoint}`;
    const res = await fetch(url, options);
    const data = await res.json();
    return data;
  } catch (err) {
    console.error('API Error:', err);
    return { success: false, message: 'Network error. Please try again.' };
  }
}

function getApiBase() {
  // Detect API base from current page depth
  const path = window.location.pathname;
  const depth = (path.match(/\//g) || []).length;
  if (path.includes('/admin/') || path.includes('/customer/') || path.includes('/provider/')) {
    return '../api';
  }
  return 'api';
}

/* =============================================
   AUTH — SESSION CHECK & REDIRECT
   ============================================= */
async function checkAuth(expectedRole) {
  const res = await apiCall('/auth/check_session.php');
  if (!res.success) {
    redirectToLogin(expectedRole);
    return null;
  }
  if (expectedRole && res.user.role !== expectedRole) {
    redirectToLogin(expectedRole);
    return null;
  }
  return res.user;
}

function redirectToLogin(role) {
  const loginMap = { admin: '../admin/login.html', provider: '../provider/login.html', customer: '../customer/login.html' };
  window.location.href = loginMap[role] || '../index.html';
}

async function logout() {
  showLoading('Logging out...');
  await apiCall('/auth/logout.php', 'POST');
  hideLoading();
  window.location.href = '../index.html';
}

/* =============================================
   LOCAL STORAGE SESSION CACHE
   ============================================= */
function saveUser(user) {
  localStorage.setItem('isp_user', JSON.stringify(user));
}
function getUser() {
  try { return JSON.parse(localStorage.getItem('isp_user')); } catch { return null; }
}
function clearUser() {
  localStorage.removeItem('isp_user');
}

/* =============================================
   FORMATTERS
   ============================================= */
function formatCurrency(amount) {
  return '₹' + parseFloat(amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatDateTime(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function timeAgo(dateStr) {
  const seconds = Math.floor((new Date() - new Date(dateStr)) / 1000);
  const intervals = [[31536000,'year'],[2592000,'month'],[86400,'day'],[3600,'hour'],[60,'minute'],[1,'second']];
  for (const [s, label] of intervals) {
    const count = Math.floor(seconds / s);
    if (count > 0) return `${count} ${label}${count > 1 ? 's' : ''} ago`;
  }
  return 'just now';
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

function capitalizeFirst(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1).replace(/_/g, ' ');
}

/* =============================================
   BADGE BUILDER
   ============================================= */
function statusBadge(status) {
  const map = {
    active:       ['active', '● Active'],
    inactive:     ['inactive', '● Inactive'],
    suspended:    ['suspended', '● Suspended'],
    open:         ['warning', '○ Open'],
    in_progress:  ['in-progress', '◐ In Progress'],
    resolved:     ['success', '✓ Resolved'],
    closed:       ['closed', '✕ Closed'],
    success:      ['success', '✓ Success'],
    pending:      ['pending', '◌ Pending'],
    failed:       ['failed', '✕ Failed'],
    refunded:     ['expired', '↩ Refunded'],
    cancelled:    ['expired', '✕ Cancelled'],
    expired:      ['expired', '⌛ Expired'],
    operational:  ['success', '● Operational'],
    maintenance:  ['maintenance', '⚙ Maintenance'],
    outage:       ['outage', '⚠ Outage'],
    urgent:       ['urgent', '🔴 Urgent'],
    high:         ['high', '🟠 High'],
    medium:       ['medium', '🔵 Medium'],
    low:          ['low', '⚪ Low'],
  };
  const [cls, text] = map[status] || ['expired', status];
  return `<span class="badge badge-${cls}">${text}</span>`;
}

function planBadge(badge) {
  if (!badge) return '';
  const map = {
    Popular: 'badge-popular', 'Best Value': 'badge-best', Student: 'badge-student', Enterprise: 'badge-enterprise'
  };
  return `<span class="badge ${map[badge] || 'badge-active'}">${badge}</span>`;
}

/* =============================================
   TABLE BUILDER
   ============================================= */
function buildTable(headers, rows, options = {}) {
  if (!rows || rows.length === 0) {
    return `<div class="empty-state">
      <i class="fas fa-inbox"></i>
      <h3>No records found</h3>
      <p>${options.emptyMsg || 'No data available.'}</p>
    </div>`;
  }
  const headerHTML = headers.map(h => `<th>${h}</th>`).join('');
  const rowsHTML = rows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join('')}</tr>`).join('');
  return `
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr>${headerHTML}</tr></thead>
        <tbody>${rowsHTML}</tbody>
      </table>
    </div>`;
}

/* =============================================
   MODAL HELPERS
   ============================================= */
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.add('active');
}
function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('active');
}
function closeAllModals() {
  document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
}

// Close modal on overlay click
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('active');
  }
});

// Close modal on × button
document.addEventListener('click', function(e) {
  if (e.target.closest('.modal-close')) {
    const overlay = e.target.closest('.modal-overlay');
    if (overlay) overlay.classList.remove('active');
  }
});

/* =============================================
   SIDEBAR ACTIVE LINK
   ============================================= */
function setActiveNavItem() {
  const currentPage = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-item').forEach(item => {
    const href = item.getAttribute('href') || '';
    if (href && href.includes(currentPage)) {
      item.classList.add('active');
    }
  });
}

/* =============================================
   MOBILE SIDEBAR TOGGLE
   ============================================= */
function initMobileSidebar() {
  const btn = document.querySelector('.mobile-menu-btn');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar) return;
  btn.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    if (overlay) overlay.classList.toggle('active');
  });
  if (overlay) {
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.classList.remove('active');
    });
  }
}

/* =============================================
   USER AVATAR IN SIDEBAR
   ============================================= */
function renderSidebarUser(user) {
  const avatarEl = document.getElementById('sidebar-avatar');
  const nameEl = document.getElementById('sidebar-name');
  const roleEl = document.getElementById('sidebar-role');
  if (avatarEl && user) avatarEl.textContent = getInitials(user.name);
  if (nameEl && user) nameEl.textContent = user.name;
  if (roleEl && user) roleEl.textContent = capitalizeFirst(user.role);
}

/* =============================================
   STAR RATING WIDGET
   ============================================= */
function initStarRating(containerId, inputId) {
  const container = document.getElementById(containerId);
  const input = document.getElementById(inputId);
  if (!container || !input) return;

  const stars = container.querySelectorAll('.star');
  let currentRating = 0;

  stars.forEach((star, idx) => {
    star.addEventListener('click', () => {
      currentRating = idx + 1;
      input.value = currentRating;
      stars.forEach((s, i) => s.classList.toggle('active', i < currentRating));
    });
    star.addEventListener('mouseenter', () => {
      stars.forEach((s, i) => s.classList.toggle('active', i <= idx));
    });
  });
  container.addEventListener('mouseleave', () => {
    stars.forEach((s, i) => s.classList.toggle('active', i < currentRating));
  });
}

/* =============================================
   SCROLL ANIMATIONS
   ============================================= */
function initScrollAnimations() {
  const els = document.querySelectorAll('.animate-on-scroll');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('visible'), i * 80);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => observer.observe(el));
}

/* =============================================
   COUNTER ANIMATION
   ============================================= */
function animateCounter(el, target, duration = 1500) {
  const start = performance.now();
  const initial = 0;
  const update = (time) => {
    const elapsed = time - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 4);
    el.textContent = Math.round(initial + (target - initial) * eased).toLocaleString('en-IN');
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

function initCounters() {
  document.querySelectorAll('[data-counter]').forEach(el => {
    const target = parseInt(el.dataset.counter);
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        animateCounter(el, target);
        observer.unobserve(el);
      }
    });
    observer.observe(el);
  });
}

/* =============================================
   TABS
   ============================================= */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tabGroup = this.closest('.tabs');
      const contentGroup = tabGroup.nextElementSibling;
      const target = this.dataset.tab;

      tabGroup.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');

      if (contentGroup && contentGroup.classList.contains('tab-content')) {
        contentGroup.querySelectorAll(':scope > div').forEach(panel => {
          panel.classList.toggle('active', panel.id === target);
        });
      }
    });
  });
}

/* =============================================
   CONFIRM DIALOG
   ============================================= */
function showConfirm(message, onConfirm) {
  const existing = document.getElementById('confirm-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'confirm-modal';
  modal.className = 'modal-overlay active';
  modal.innerHTML = `
    <div class="modal" style="max-width:400px">
      <div class="modal-body" style="padding:32px 28px">
        <div style="text-align:center;margin-bottom:20px">
          <div style="width:56px;height:56px;border-radius:50%;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:1.4rem;color:var(--red-400)">
            <i class="fas fa-triangle-exclamation"></i>
          </div>
          <h3 style="margin-bottom:8px">Confirm Action</h3>
          <p style="color:var(--text-muted);font-size:0.88rem">${message}</p>
        </div>
        <div style="display:flex;gap:12px;justify-content:center">
          <button class="btn btn-secondary" id="confirm-no" style="min-width:100px">Cancel</button>
          <button class="btn btn-danger" id="confirm-yes" style="min-width:100px">Confirm</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(modal);

  document.getElementById('confirm-yes').onclick = () => { modal.remove(); onConfirm(); };
  document.getElementById('confirm-no').onclick = () => modal.remove();
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
}

/* =============================================
   PAGINATION HELPER
   ============================================= */
function buildPagination(containerEl, currentPage, totalPages, onPageChange) {
  containerEl.innerHTML = '';
  if (totalPages <= 1) return;

  const createBtn = (label, page, disabled = false) => {
    const btn = document.createElement('button');
    btn.className = `page-btn${page === currentPage ? ' active' : ''}`;
    btn.innerHTML = label;
    btn.disabled = disabled;
    btn.onclick = () => !disabled && page !== currentPage && onPageChange(page);
    return btn;
  };

  containerEl.appendChild(createBtn('<i class="fas fa-chevron-left"></i>', currentPage - 1, currentPage <= 1));
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || Math.abs(i - currentPage) <= 1) {
      containerEl.appendChild(createBtn(i, i));
    } else if (Math.abs(i - currentPage) === 2) {
      const dots = document.createElement('span');
      dots.textContent = '...';
      dots.style.cssText = 'color:var(--text-muted);padding:0 4px;line-height:36px';
      containerEl.appendChild(dots);
    }
  }
  containerEl.appendChild(createBtn('<i class="fas fa-chevron-right"></i>', currentPage + 1, currentPage >= totalPages));
}

/* =============================================
   INITIALIZE ON DOM READY
   ============================================= */
document.addEventListener('DOMContentLoaded', function() {
  setActiveNavItem();
  initMobileSidebar();
  initScrollAnimations();
  initCounters();
  initTabs();
});
